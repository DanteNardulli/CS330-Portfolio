import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    @Test
    void testTaskCreation() {
        Task task = new Task("12345", "Test Name", "Test Description");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Name", task.getName());
        assertEquals("Test Description", task.getDescription());
    }

    @Test
    void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Description"));
    }

    @Test
    void testSetName() {
        Task task = new Task("12345", "Old Name", "Description");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    @Test
    void testSetInvalidName() {
        Task task = new Task("12345", "Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName("This name is way too long to be valid"));
    }

    @Test
    void testSetDescription() {
        Task task = new Task("12345", "Name", "Old Description");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    @Test
    void testSetInvalidDescription() {
        Task task = new Task("12345", "Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("This description is way too long to be valid and will throw an exception"));
    }
}
