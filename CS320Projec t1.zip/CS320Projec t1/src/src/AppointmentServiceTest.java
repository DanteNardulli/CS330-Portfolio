package src;

import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class AppointmentServiceTest {

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appointment = new Appointment("1234567890", futureDate, "Test appointment");

        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("1234567890"));
    }

    @Test
    void testAddDuplicateAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appointment1 = new Appointment("1234567890", futureDate, "Test appointment");
        Appointment appointment2 = new Appointment("1234567890", futureDate, "Duplicate ID");

        service.addAppointment(appointment1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appointment = new Appointment("1234567890", futureDate, "Test appointment");

        service.addAppointment(appointment);
        service.deleteAppointment("1234567890");
        assertNull(service.getAppointment("1234567890"));
    }

    @Test
    void testDeleteNonExistentAppointment() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("nonExistentId");
        });
    }
}