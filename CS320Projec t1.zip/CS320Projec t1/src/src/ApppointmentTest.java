package src;

import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    @Test
    void testAppointmentCreationValid() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000); // 10 seconds in the future
        Appointment appointment = new Appointment("1234567890", futureDate, "Meeting with client");
        assertNotNull(appointment);
    }

    @Test
    void testAppointmentIdTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Invalid ID");
        });
    }

    @Test
    void testAppointmentDateInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", pastDate, "Past appointment");
        });
    }

    @Test
    void testAppointmentDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, "This description is definitely more than fifty characters long and should fail.");
        });
    }
}
