import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts = new HashMap<>();

    // Add a contact
    public boolean addContact(Contact contact) {
        if (contact != null && !contacts.containsKey(contact.getContactId())) {
            contacts.put(contact.getContactId(), contact);
            return true;
        }
        return false;
    }

    // Delete a contact
    public boolean deleteContact(String contactId) {
        if (contactId != null && contacts.containsKey(contactId)) {
            contacts.remove(contactId);
            return true;
        }
        return false;
    }

    // Update a contact
    public boolean updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            if (firstName != null) contact.setFirstName(firstName);
            if (lastName != null) contact.setLastName(lastName);
            if (phone != null) contact.setPhone(phone);
            if (address != null) contact.setAddress(address);
            return true;
        }
        return false;
    }

    // Get a contact by ID
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}