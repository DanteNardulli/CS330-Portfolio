import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertTrue(contactService.addContact(contact));
        assertNotNull(contactService.getContact("12345"));
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        Contact duplicateContact = new Contact("12345", "Jane", "Doe", "0987654321", "456 Oak St");
        assertFalse(contactService.addContact(duplicateContact));  // ID must be unique
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.deleteContact("12345"));
        assertNull(contactService.getContact("12345"));
    }

    @Test
    public void testDeleteNonExistingContact() {
        assertFalse(contactService.deleteContact("99999"));  // No contact with this ID
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContact("12345", "Jane", null, "0987654321", "456 Oak St");
        
        Contact updatedContact = contactService.getContact("12345");
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("456 Oak St", updatedContact.getAddress());
    }

    @Test
    public void testUpdateNonExistingContact() {
        assertFalse(contactService.updateContact("99999", "Jane", "Doe", "0987654321", "456 Oak St"));
    }

    @Test
    public void testGetContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        Contact fetchedContact = contactService.getContact("12345");
        assertEquals(contact, fetchedContact);
    }

    @Test
    public void testGetNonExistingContact() {
        assertNull(contactService.getContact("99999"));
    }
}
