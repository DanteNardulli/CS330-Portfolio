import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "Name", "Description");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("12345"));
    }

    @Test
    void testAddDuplicateTaskId() {
        TaskService taskService = new TaskService();
        Task task1 = new Task("12345", "Name1", "Description1");
        Task task2 = new Task("12345", "Name2", "Description2");
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    void testDeleteTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "Name", "Description");
        taskService.addTask(task);
        taskService.deleteTask("12345");
        assertNull(taskService.getTask("12345"));
    }

    @Test
    void testDeleteNonExistentTask() {
        TaskService taskService = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("12345"));
    }

    @Test
    void testUpdateTaskName() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "Old Name", "Description");
        taskService.addTask(task);
        taskService.updateTaskName("12345", "New Name");
        assertEquals("New Name", taskService.getTask("12345").getName());
    }

    @Test
    void testUpdateTaskDescription() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "Name", "Old Description");
        taskService.addTask(task);
        taskService.updateTaskDescription("12345", "New Description");
        assertEquals("New Description", taskService.getTask("12345").getDescription());
    }

    @Test
    void testUpdateNonExistentTask() {
        TaskService taskService = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("12345", "Name"));
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskDescription("12345", "Description"));
    }
}
